
#ifndef AIRLINE_H
#define AIRLINE_H

#include <iostream>
#include <string>
#include <iomanip>
#include "Date.h"
#include "Part.h"
#include "Aircraft.h"

using namespace std;

class Airline {

	friend ostream& operator<<(ostream& out, Airline&);

	public:
		//constructor
		Airline(const string&);
		~Airline();		
		
		void addAircraft(const string&, const string&);
		void addPart(const string&, int, int);
		
		void takeFlight(const string&, int);
		void printAircraft();
		void printParts();
		
		void inspectionReport(const string&, Date&);
		
		bool install (const string&, const string&, Date&);
	
	private:
	
		//variables
		const string& name;
		Array <Part*> partArr;
		Array<Aircraft*>airArr;
		void getAircraft(const string&,Aircraft**);
		void getParts(const string&,Part**);
	
	
};
#endif
