#ifndef AIRCRAFT_H
#define AIRCRAFT_H

#include <iostream>
#include <string>
#include <iomanip>

#include "Array.h"
#include "Part.h"
using namespace std;

class Aircraft {

	friend ostream& operator<<(ostream& out, Aircraft&);

	public:
		//constructor
		Aircraft(const string&, const string&);
		~Aircraft();
		
		//getters
		const string& getReg();
		
		void install(Part*, Date&);
		
		void takeFlight(int);
		
		void inspectionReport(Date&, Array<Part*>&);
	
	private:
	
		//variables
		const string& type;
		const string& registration;
		int flighthours;
		Array <Part*> partArr;
};
#endif
