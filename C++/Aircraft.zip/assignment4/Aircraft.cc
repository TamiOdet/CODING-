
#include "Aircraft.h"

Aircraft::Aircraft(const string& t, const string& reg):type(t), registration(reg){
}

Aircraft::~Aircraft(){}


//getters
const string& Aircraft::getReg(){ return registration; }


//other

void Aircraft::install(Part* p, Date& d) {
	p->install(d);
	partArr.add(p);

}

void Aircraft::takeFlight(int hours){
	for(int i = 0; i<partArr.getSize(); ++i){
		partArr[i]->addFlightHours(hours);
	}

}

void Aircraft::inspectionReport(Date& d, Array<Part*>& p){
	for(int i = 0; i<partArr.getSize(); ++i)
		if(partArr[i]->inspection(d) == true){
			(&p)->add(partArr[i]);

		}
	}


ostream& operator<<(ostream& out, Aircraft& a){
	return out <<"Aircraft: "<<a.type<<" registration: "<<a.registration<<endl;
}
