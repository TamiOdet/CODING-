
#include "Airline.h"

Airline::Airline(const string& n):name(n){

	//partArr = new  ();
	//airArr;

}

Airline::~Airline(){
	//delete partArr;
	//delete airArr;
}



void Airline::takeFlight(const string& reg, int hours){

	for(int i = 0; i<airArr.getSize(); ++i){
		if(airArr[i]->getReg() == reg){
			airArr[i]->takeFlight(hours);
		}
	}

}


void Airline::getAircraft(const string& a, Aircraft **ai){
	for(int i = 0; i < airArr.getSize(); ++i){
		if(airArr[i]->getReg() == a){
		*ai = airArr[i];
		}
	}
}
void Airline::getParts(const string& n, Part **p){
	for(int i = 0; i < partArr.getSize(); ++i){
		if(partArr[i]->getName() == n){
			*p = partArr[i];
		}
	}

}

void Airline::addAircraft(const string& t, const string& r ){
	Aircraft *newAir = new Aircraft(t,r);
	airArr.add(newAir);
}

void Airline::addPart(const string& part, int fh_inspect, int it_inspect){
	if(fh_inspect == 0){
		IT_Part *it = new IT_Part(part,it_inspect);
		partArr.add(it);

	}else if (it_inspect == 0){
		FH_Part *fh = new FH_Part(part,fh_inspect);
		partArr.add(fh);

	}else{
		FHIT_Part *fhit = new FHIT_Part(part,fh_inspect,it_inspect);
		partArr.add(fhit);

	}



}

void Airline::printAircraft(){
	for(int i = 0; i < airArr.getSize(); ++i){
		cout<<*airArr[i]<<endl;
	}
}
void Airline::printParts(){
	for(int i = 0; i < partArr.getSize(); ++i){
			cout<<*partArr[i]<<endl;
		}
}
void Airline::inspectionReport(const string& reg, Date& d){
	Array<Part*> p;

	for(int i = 0; i<airArr.getSize(); ++i){

		if(airArr[i]->getReg() == reg){
			airArr[i]->inspectionReport(d,p);
			cout<<"Aircraft registration "<<airArr[i]->getReg()<<endl;
			for(int i = 0; i < p.getSize(); ++i){

					cout<<*p[i]<<endl;
			}

		}else{
			cout<<"error!! does not exist"<<endl;
		}

	}
}

bool Airline::install (const string& reg, const string& pname, Date& d){
	for(int i = 0; i < airArr.getSize(); ++i){
		if(airArr[i]->getReg() == reg){
			for(int j = 0; j < partArr.getSize(); ++j){
					if(partArr[j]->getName() == pname){
						airArr[i]->install(partArr[j],d);
					}
			}
			return true;
		}

	}
return false;
}
ostream& operator<<(ostream& out, Airline& a){
	return out <<"Airline name "<<a.name<<endl;
}
