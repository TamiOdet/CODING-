
#ifndef PART_H
#define PART_H

#include <iostream>
#include <string>
#include <iomanip>
#include "Date.h"
using namespace std;

class Part {
friend ostream& operator <<(ostream&, const Part&);
	public:
		//constructor
		Part(const string&);
		virtual ~Part();
		//getters
		string getName() const;

		void addFlightHours(int);
		void install(Date&);
		virtual bool inspection(Date&)=0;
		

	protected:
		//variables
		string name;
		Date installationDate;
		int flightHours;
		virtual void print(ostream&) const=0;

};

class FH_Part : virtual public Part{
	public:
		//constructor
		FH_Part(const string&, int);
		virtual ~FH_Part();
		virtual bool inspection(Date&);

	protected:
		//variables
		int fh_inspect;
		virtual void print(ostream&) const;
};

class  IT_Part: virtual public Part{
	public:
		//constructor
		IT_Part(const string&, int);
		virtual ~IT_Part();
		virtual bool inspection(Date&);

	protected:
		//variables
		int it_inspect;
		virtual void print(ostream&) const;
};
class FHIT_Part : virtual public Part, public FH_Part, public IT_Part {
	public:
		//constructor
		FHIT_Part(const string&, int, int);
		virtual ~FHIT_Part();
		virtual bool inspection(Date&);
	protected:
	virtual void print(ostream&) const;


};
#endif
