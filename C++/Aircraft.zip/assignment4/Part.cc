
#include "Part.h"



Part::Part(const string&  name): name(name), flightHours(0){

}

Part::~Part(){
}

void Part::addFlightHours(int h){
	flightHours = flightHours + h;

}
string Part:: getName() const{
	return name;
}
void Part::install(Date& p){
	installationDate = p;
}

void Part::print(ostream& os) const{
	os <<"Part name: " << name << endl;
	os <<"flightHours: "<<flightHours<<endl;
	if(installationDate.getMonthName() == "January"){
		os<<"Not installed"<<endl;
	}else{
		os << installationDate.getMonthName()<<" "<<installationDate.getDay()<<", "<<installationDate.getYear()<<endl;
	}



}


FH_Part::FH_Part(const string& na, int fh) : Part(na), fh_inspect(fh){

}
FH_Part::~FH_Part(){
}


//date of the inspection
bool FH_Part::inspection(Date& d){
	if(flightHours >= fh_inspect){

		return true;
	}
	return false;
}

void FH_Part::print(ostream& os)const{
	os <<"FH Part name: " << name<<endl;
	os <<"flightHours: "<<flightHours<<endl;
	os << installationDate.getMonthName()<<" "<<installationDate.getDay()<<", "<<installationDate.getYear()<<endl;
	os << "inspect every: "<<fh_inspect<<" flight hours"<<endl;
}


IT_Part::IT_Part(const string& na, int it) : Part(na), it_inspect(it) {

}

IT_Part::~IT_Part(){
}

bool IT_Part::inspection(Date& d){
	int numId = installationDate.toDays();
	int insId = d.toDays();

	if((insId - numId) >= it_inspect){
		return true;
	}
	return false;
}

void IT_Part::print(ostream& os)const{
	os <<"IT Part name: " << name <<endl;
	os <<"flightHours: "<<flightHours<<endl;
	os << installationDate.getMonthName()<<" "<<installationDate.getDay()<<", "<<installationDate.getYear()<<endl;
	os << "inspect every: "<<it_inspect<<" days installed"<<endl;
}

FHIT_Part::FHIT_Part(const string& na, int fh, int it) : Part(na), FH_Part(na,fh), IT_Part(na,it) {

}

FHIT_Part::~FHIT_Part(){
}

bool FHIT_Part::inspection(Date& d){
	if (FH_Part::inspection(d) == true || IT_Part::inspection( d) == true){
		return true;
	}
return false;

}

void FHIT_Part::print(ostream& os)const{
	os <<"FHIT Part name: " << name <<endl;
	os <<"flightHours: "<<flightHours<<endl;
	os << installationDate.getMonthName()<<" "<<installationDate.getDay()<<", "<<installationDate.getYear()<<endl;
	os << "inspect every: "<<fh_inspect<<" flight hours"<<endl;
	os << "inspect every: "<<it_inspect<<" installed"<<endl;
}



ostream& operator<<(ostream& os,const Part& p){
	p.print(os);
	return os;
}
