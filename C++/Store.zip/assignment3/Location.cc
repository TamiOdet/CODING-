#include <iostream>
#include <sstream>
using namespace std;
#include <string>

#include "Location.h"


//int Location::nextId = 1000;
const string Location::NONE = "Empty";
Location::Location (char c, int n)
{
	stringstream ss;
	ss << c << n;
	id = ss.str();
  product = NONE;
  quantity = 0;
//  NONE = "Empty";
}

Location::~Location()
{
}


string Location::getId() const{
	return id;
}
string Location::getProduct()  const{
	return product;
}
int Location::getQuantity()  const{
	return quantity;
}



bool Location::isEmpty(){
	if(quantity == 0){
		return true;
	}
	return false;
}

bool Location::isAvailable(){
	if (product == NONE){
		return true;
	}
	return false;
}

void Location::print() const{
  cout<<"Location id: "<<id<<endl;
	cout<<"Product: "<<product<<endl;
	cout<<"Quantity: "<<quantity<<endl;
	cout<<""<<endl;
}
