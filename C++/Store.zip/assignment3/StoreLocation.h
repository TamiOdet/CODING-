#ifndef STORE_LOCATION_H
#define STORE_LOCATION_H

#include <string>
#include <iostream>
#include "Location.h"
#include "defs.h"

using namespace std;

class StoreLocation: public Location {
    public:
        StoreLocation();
        virtual ~StoreLocation();
        void setProduct(string);
        int getFreeSpace();
        bool addQuantity(int); //fucntion adds the new amount to the quantity
        virtual int getCapacity();
        virtual  bool add(string, int);
        virtual bool remove(int);

    private:
        static const char code = 'A';
        static const int capacity = SLOC_CAPACITY;
        static int nextId;


};



#endif
