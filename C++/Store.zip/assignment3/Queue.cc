#include <iostream>
#include <string>
using namespace std;

#include "Queue.h"


Queue::Queue(): head(NULL), tail(NULL){}


Queue::~Queue(){
    Node* currNode = head;
    Node* prevNode = NULL;

    while(currNode!=NULL){
        prevNode = currNode;
        currNode = currNode->next;
        //delete prevNode->data;
        delete prevNode;
    }

}

bool Queue::isEmpty() const{
    Node* currNode = head;
    if (currNode == NULL){
    	return true;
    } //empty
    return false;
}

void Queue :: peekFirst(WHLocation** stu){
	 Node* currNode = head;
	if(head != NULL){
		*stu = currNode->data;
	}else{
		*stu = NULL;
		//gets seg fault if there is nothing in the list and it is assigned to NULL
	}
}

void Queue :: popFirst(WHLocation** stu){
	/*Node* currTail = tail;
	tail = tail->next;
	delete currTail;
	*stu = currTail->data;*/

	Node* currNode = head;
	//Node* prevNode = NULL;
	cout<<"popping first element"<<endl;
	if(currNode != NULL){

		*stu = currNode->data;
		head = currNode->next;
		//assign the next item to be the new head
		delete currNode;


	}else{
		*stu = NULL;
		//gets seg fault if there is nothing in the list and it is assigned to NULL
	}
}

void Queue ::addLast(WHLocation* stu){
	cout<<"adding students to the end"<<endl;
	Node* newNode = new Node();
	Node* currTail = tail;
	newNode->data = stu;
	newNode->next = NULL;

	//Node* currTail = tail;
	Node* currNode = head;

	if(head == NULL){
    	head = newNode;
    	tail = newNode;
    	return;
       }else{//while linked lsit is not empty
		tail->next = newNode;
		tail = newNode;



	}
	 currTail = newNode;
}

void Queue::print() const{
    Node* currNode = head;
    cout<<"Print Queue..."<<endl;

    if (currNode == NULL){
        cout <<"Queue empty"<<endl;
    }

    while(currNode != NULL){
        currNode->data->print();
        currNode = currNode->next;
    }
}
