#ifndef WH_LOCATION_H
#define WH_LOCATION_H

#include <string>
#include <iostream>
#include "Location.h"
#include "defs.h"

using namespace std;

class WHLocation: public Location {
    public:
        WHLocation();
        virtual ~WHLocation();
        bool addQuantity(int); // adds the new amount to the quantity
        virtual int getCapacity() ;
        virtual bool add(string, int);
        virtual bool remove(int);



    private:
        static const char code = 'B';
        static const int capacity = WHLOC_CAPACITY;
        static int nextId;


};



#endif
