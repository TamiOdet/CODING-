#include "WHLocation.h"


int WHLocation::nextId= nextId+1;
//char WHLocation::code= 'A';
//int WHLocation::capacity = SLOC_CAPACITY;
WHLocation::WHLocation() : Location (code, nextId++){
}

WHLocation::~WHLocation(){
}


int WHLocation::getCapacity(){
  return capacity;
}
bool WHLocation::addQuantity(int a){
  quantity = a + quantity;
  if (quantity <= capacity){
    return true;
  }
  return false;
}
bool WHLocation:: remove(int amount){
  if (amount >= quantity){
    return false;
  }else if ((quantity - amount) == 0){
    quantity = quantity - amount;
    product == NONE;
  }
  quantity = quantity - amount;
  return true;
}



bool WHLocation:: add(string prod, int amount){
  //trues to add the amount quant to prod
  if (isAvailable() && ((amount + quantity) <= capacity)){
    //prod = "beans";
      product = prod;
      addQuantity(amount);
      return true;
  }
  return false;

}
