#include <iostream>
#include "Control.h"
#include "WHLocation.h"

using namespace std;



int main(){
	
	Control control;

	cout << "Launching..."<<endl;

	control.launch();

	
}

