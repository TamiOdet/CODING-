#include "StoreLocation.h"


int StoreLocation::nextId= nextId+1;

StoreLocation::StoreLocation() : Location (code, nextId++){
}

StoreLocation::~StoreLocation(){
}

void StoreLocation::setProduct(string s){
  product = s;
}

int StoreLocation::getFreeSpace(){
  return capacity-quantity; // returns the leftover space thelocation has
}

int StoreLocation::getCapacity(){
  return capacity;
}
bool StoreLocation::addQuantity(int a){
  quantity = a + quantity;
  if (quantity <= capacity){
    return true;
  }
  return false;
}
bool StoreLocation:: remove(int amount){
  if (amount >= quantity){
    return false;
  }
  quantity = quantity - amount;
  return true;

}


bool StoreLocation:: add(string prod, int amount){
  //trues to add the amount quant to prod
  if (isAvailable() && ((amount + quantity) <= capacity)){
    //prod = "beans";
      setProduct(prod);
      addQuantity(amount);
      return true;
  }else if ((prod != product) || ((amount + quantity) >= capacity)) {
    return false;

  }else{
    //setProduct(prod);
    addQuantity(amount);
    return true;
  }
  return false;
}
