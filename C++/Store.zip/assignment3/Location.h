#ifndef LOCATION_H
#define LOCATION_H

#include <string>

using namespace std;

class Location
{
  public:
    Location(char,int);
    virtual ~Location();
    string getId() const;
    string getProduct()  const;
    int getQuantity()  const;
    void print()   const;
    bool isEmpty();
    bool isAvailable(); // no prooduct at this location meaning it is available to add a product to it
    virtual int getCapacity() = 0;
   //virtual function that adds the quantity specified to the amount already there
    virtual bool add(string, int) = 0;
    virtual bool remove(int) = 0;

protected:
    string id; //label of this location
  	string product; //name of product stored at the location
  	int quantity; //quantity of product stored at the location
    static const string NONE; //when there is no product at the location, set product at the location to none (similar to NULL)
  	//static int nextId;

};

#endif
