#ifndef QUEUE_H
#define QUEUE_H

#include "WHLocation.h"

class Queue{

    //friend class Student;

    //private by default
    class Node {

        public:
            WHLocation* data;
            Node*    next;
    };

    public:
        Queue();

        // Any data left in the Queue gets destroyed
        ~Queue();
        //we have unlimited size, so add always succeeds
        //void get(const string& name, Student**);
        //double pointer for a return parameter of a pointer
        //void remove(const string& name, Student**);

        //void removeUpTo(const string& name);

        void print()const;  //not modify this Queue object

        void peekFirst(WHLocation**);

        bool isEmpty()  const;

        void popFirst(WHLocation**);

        void addLast(WHLocation*);



    private:
        Node* head;
        Node* tail; //points to the last element in the queueu making it easier to add elements to the back of tyhe queue

};


#endif
