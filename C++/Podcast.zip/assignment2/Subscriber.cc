#include "Subscriber.h"
#include <iostream>



Subscriber::Subscriber(const string& n,const string& c){
	name = n;
	creditC = c;
}

Subscriber::Subscriber(){
	name = "NULL";
	creditC = "NULL";
}
bool Subscriber::matches(const string& name){
	if(this->name == name){
		return true;
	}else{
		return false;
	}
}



void Subscriber::print(){
	cout<<"Subscriber name: "<<name<<endl;
	cout<<"Subscriber creditcard: "<<creditC<<endl;
}



