#include "Episode.h"
#include <iostream>



Episode::Episode(const string& pod, int num, const string& nam, const string& cont){
	podcast = pod;
	epNum = num;
	name = nam;
	content = cont;
}

Episode::Episode(){

	podcast = "NULL";
	epNum = 0;
	name = "NULL";
	content = "NULL";
}





void Episode::play(){
	std::cout<<"Now listening to: "<<podcast<<endl;
	std::cout<<"Episode "<<epNum<<": "<<name<<endl;
	std::cout<<content<<endl;
	
}

void Episode::print(){
	cout<<"Podcast Name: "<<podcast<<endl;
	cout<<"Episode Name: "<<name<<endl;
	cout<<"Episode Number: "<<epNum<<endl;
	cout<<"Episode Content "<<endl;
	cout<<content<<endl;
}



