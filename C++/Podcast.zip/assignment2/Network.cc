#include "Network.h"
#include <iostream>

Network::Network(const string& n){
	name = n;
	numSubs = 0;
	podArr = new PodArray(); 
	for(int i = 0; i< numSubs; ++i){
		subArr[i] = new Subscriber();
	}
}

Network::~Network(){
	for(int i = 0; i<numSubs; ++i){
		delete subArr[i];
	}
	
	delete podArr;
}

bool Network::getPodcast(const string& pod,Podcast** podcast){
	return podArr->getPodcast(pod,podcast);
}



bool Network::addPodcast(const string& podcast,const string& host){
	Podcast *pod = new Podcast(podcast,host);
	if (podArr->isFull()) return false;
	podArr->addPodcast(pod); 
	
	//delete pod;
}


bool Network::removePodcast(const string& podcast){
Podcast *pod;
	//if(podArr->getPodcast(podcast,&pod) == true){
	podArr->removePodcast(podcast,&pod);
	//}
	delete pod;
return false;
}


bool Network::addEpisode(const string& podcast,const string& title,const string& content){
Podcast *pod;
if(podArr->getPodcast(podcast,&pod) == true){
	pod->addEpisode(title,content);
}

return false;

}

bool Network::addSubscriber(const string& name,const string& creditcard){
	if(numSubs >= MAX_SUBS){
		return false;
	}else{
		Subscriber *sub = new Subscriber(name,creditcard);
		subArr[numSubs++] = sub;
		//delete sub;
		return true;
		
	}
}
 // Client services
bool Network::download(const string& subscriber,const string& podcast,Podcast** pod){
		if(hasSubscriber(subscriber)){
			if(podArr->getPodcast(podcast,pod)){
				return true;
			}else{
				std::cout<<"there is no such podcast"<<endl;
				return false;
			}	
		}
		std::cout<<"there is no such podcast"<<endl;
		return false;

}
bool Network::stream(const string& subscriber,const string& podcast, int episode,Episode** ep){
	Podcast *p;
	int check= true;
		if(hasSubscriber(subscriber)){
			if(podArr->getPodcast(podcast,&p)){
				if(episode <= p->getNumEpisodes()){
					p->getEpisode(episode,ep);
					return true;
				}else{
				return false;
				}
			
			}else{
				std::cout<<"no such podcast "<<endl;
				return false;
			}
		}else{
			std::cout<<"no such Subscriber "<<endl;
			return false;
		}
	
	return check;

}
bool Network::hasSubscriber(const string& name){
	for(int i = 0; i < numSubs; ++i){
		if(subArr[i]->matches(name)){
		return true;}
	}
return false;
}

void Network::print(){
	cout<<"Network name: "<<name<<endl;
	podArr->print();
	for(int i = 0; i<numSubs; ++i)
		subArr[i]->print();
}
