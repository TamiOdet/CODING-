#ifndef PODCAST_H
#define PODCAST_H
#include <iostream>
#include <string>
#include "Episode.h"
#include "defs.h"

//Class: Podcast
//Purpose: contains podcast declarations and implementations and manages collection of episodes

using namespace std;

class Podcast {
		
	public:
		
		Podcast(const string&,const string&);
		Podcast(const Podcast&);
		Podcast();
		~Podcast();
		const string& getTitle();
		const string& getHost();
		int getNumEpisodes();
		bool addEpisode(string, string);
		bool getEpisode(int, Episode**);
		bool lessThan(Podcast&);
		void print();
	
	private:
		string title;
		string host;
		Episode** episodes;
		int numEps;
};
#endif
