#include "Client.h"
#include <iostream>

Client::Client(const string& n){
	name = n;
	podArr = new PodArray();
}

void Client::download(Network* network, const string& podcast){
	Podcast* podc;
	if (network->download(name, podcast, &podc) == true){
			Podcast* newPod = new Podcast(*podc);
			podArr->addPodcast(newPod);
			//delete newPod;
	}
}

Client::~Client(){
	delete podArr;
}
void Client::stream (Network* network, const string& podcast, int episode){
	Episode *ep;
	if(network->stream(name,podcast,episode,&ep) == true){
		ep->play();
	}
	
}
void Client::playLocal(const string& podcast, int episode){

	Podcast* p;
	if(podArr->getPodcast(podcast,&p)){
		Episode * e;
		p->getEpisode(episode,&e);
		e->play();
	}else{
		std::cout<<"The podcast does not exist";
	}
}

void Client::print(){
	cout<<"Client name: "<<name<<endl;
	podArr->print();
}




