#ifndef EPISODE_H
#define EPISODE_H
#include <iostream>
#include <string>

//Class: Episode
//Purpose: contains variables and function declarations for Episodes
using namespace std;

class Episode {
		
	public:
		
		Episode(const string&, int,const string&, const string& );
		Episode();
		void play();
		void print();
		string getName();
	
	private:
		string name;
		string content;
		string podcast;
		int epNum;

};
#endif
