#ifndef NETWORK_H
#define NETWORK_H
#include <iostream>
#include <string>
#include "defs.h"
#include "Podcast.h"
#include "PodArray.h"
#include "Subscriber.h"

//Class: Network
//Purpose: manages collection of podcasts and subscribers 
using namespace std;

class Network{
		
	public:
		
		Network(const string&);
		~Network();
		bool getPodcast(const string&,Podcast**);
		// add and remove
		bool addPodcast(const string&, const string&);
		bool removePodcast(const string&);
		bool addEpisode(const string&,const string&,const string&);
		bool addSubscriber(const string&,const string&);
 		// Client services
		bool download(const string&,const string&, Podcast**);
		bool stream(const string&,const string&,int,Episode**);
		bool hasSubscriber(const string&);
		void print();
	
	private:
		string name;
		PodArray* podArr;
		Subscriber *subArr[MAX_SUBS];
		int numSubs;
		

};
#endif
