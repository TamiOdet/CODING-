#ifndef SUBSCRIBER_H
#define SUBSCRIBER_H
#include <iostream>
#include <string>

//Class: Subscriber
//Purpose: manages podcasts and subscribers
using namespace std;

class Subscriber {
		
	public:
		//constructor
		Subscriber(const string&,const string&);
		Subscriber();
		bool matches(const string& );
		void print();
	
	private:
		string name;
		string creditC;
		

};
#endif
