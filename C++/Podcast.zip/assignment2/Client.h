#ifndef CLIENT_H
#define CLIENT_H
#include <iostream>
#include <string>
#include "defs.h"
#include "Podcast.h"
#include "PodArray.h"
#include "Subscriber.h"
#include "Network.h"

//Class: Client
//Purpose: manages collection of downladed podcasts whilst interacting with the Network
using namespace std;

class Client{
		
	public:
		//constructor
		Client(const string&);
		~Client();
		void download(Network*, const string&);
		void stream (Network*, const string&, int);
		void playLocal(const string&, int);
		void print();


	
	private:
		string name;
		PodArray* podArr;
		

};
#endif
