#include "Podcast.h"
#include <iostream>



Podcast::Podcast(const string& t,const string& h){
	title = t;
	host = h;
	numEps = 0;
	episodes = new Episode*[MAX_EPS];
	for(int i = 0; i<numEps; ++i){
		episodes[i] = new Episode();
	}
}
Podcast::Podcast(){
	title = "NULL";
	host = "NULL";
	numEps = 0;
	episodes = new Episode*[MAX_EPS];
}

Podcast::~Podcast(){
	for (int i = 0; i< numEps; ++i){	
		delete episodes[i];
	}
	delete [] episodes;
}
	
	
Podcast::Podcast(const Podcast& pod){
	title = pod.title;
	host = pod.host;
	episodes = new Episode*[MAX_EPS];
	numEps = pod.numEps;
	for (int i =0 ; i < pod.numEps; ++i){
		episodes[i] = new Episode(*pod.episodes[i]);
	}
	
	
	
	
}

const string& Podcast::getTitle(){
	return title;
}
const string& Podcast::getHost(){
	return host;
}

int Podcast::getNumEpisodes(){
	return numEps;
}

bool Podcast::addEpisode(string t, string c){
	if(numEps >= MAX_EPS){
		return false;
	}else{
		Episode *ep = new Episode(title,numEps,t,c);
		episodes[numEps++] = ep;
		return true;
	}
}

bool Podcast::getEpisode(int index, Episode** ep){
	bool x=true;
	for (int i =0; i< numEps; ++i){
		if( i == index){
			*ep= episodes[i]; 
			x = true;
		}else{
			x = false;
		}
		
	}
	return x;

}

bool Podcast::lessThan(Podcast& pod){
	return this->title < pod.title;
		
}


void Podcast::print(){
	cout<<"Title: "<<title<<endl;
	cout<<"Host: "<<host<<endl;
	
	
	
}

