#ifndef TESTVIEW_H
#define TESTVIEW_H

#include <iostream>
#include <string>
//Class: TestView
//Purpose: takes users input
using namespace std;


class TestView
{
  public:
    void showMenu(int&);
};

#endif
