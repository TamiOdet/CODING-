Program author: Oluwatamilore Odetoyinbo
purpose: to manage the reservations in a small Hotel

list of source files:
	Date.cc
	main.cc
	Guest.cc
	Room.cc
	Reservation.cc
	RoomArray.cc
	Recorder.cc
	StayRecorder.cc
	GuestRecorder.cc
	UpgradeRecorder.cc
	Hotel.cc
	ResManager.cc
	Control.cc
	View.cc
	


list of header files:
	Date.h
	main.h
	Guest.h
	Room.h
	Reservation.h
	RoomArray.h
	Recorder.h
	StayRecorder.h
	GuestRecorder.h
	UpgradeRecorder.h
	Hotel.h
	ResManager.h
	Control.h
	View.h
	defs.h
	
	
and Makefile

compilation insturctions:
	to compile use the makefile and type make in the command line
	make
to run:
	./a4
	





