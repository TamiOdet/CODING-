#ifndef CONTROL_H
#define CONTROL_H
#include "ResManager.h"
#include "View.h"
#include "Hotel.h"
#include "Recorder.h"
#include "StayRecorder.h"
#include "GuestRecorder.h"
#include "UpgradeRecorder.h"
//Class: Control
//Purpose: reswponsible for calling view object to display to user and printing out the users different selections

class Control
{
public:
	Control();
	~Control();
	void launch();



private:
	ResManager *resMgr;
	View *view;
	Hotel *hotel;
	void initHotel();
};

#endif
