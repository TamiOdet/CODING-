#include <iostream>
using namespace std;
#include <string>

#include "Hotel.h"

void addGuest(Guest*);
void addRoom(Room*);
void  printGuests();
bool findGuest(string, Guest**);

Hotel::Hotel(string h, ResManager* m) : hotel(h), man(m)
{
 size = 0;
 for (int i = 0; i< MAX_ARR; i++){
 	guests[i] = 0;
 }
//man = new ResManager(Hotel*);
// roomColl = new RoomArray;
}

Hotel::~Hotel()
{
	/* cout<<"destrucftor"<<endl;
  for (int i=0; i<size; ++i){
    delete guests[i];}
    


delete man;
//delete roomColl;
*/
}

RoomArray Hotel :: getRoomColl(){
	return roomColl;
	//not sure
}

void Hotel :: addGuest(Guest *g){
	if (size>=MAX_ARR){
		return;
	}else{
		
		guests[size] = g;
		size++;
		
	}
}

void Hotel :: addRoom(Room *r){
	if (roomColl.getSize()>=MAX_ARR){
	}else{
		roomColl.add(r);
	}
	
	
}
bool Hotel :: findGuest(string n, Guest*& g){
	//cout<<"size of guests "<<size<<endl;
	for (int i=0; i<size; i++){
		//cout<<"guest at first index "<<guests[1]->getName()<<endl;
		if (guests[i]->getName() == n){
			//cout<<"this guest exists in hotel"<<endl;
			//*g = guests[i];
			//g = &guests[i];
			g = guests[i];
			
			
			
			return true;
		}
	}
	return false;
}


void Hotel:: printGuests(){
	//cout<<"print guest"<<endl;
	cout<<size<<endl;
	for(int i = 0; i<size; i++){
		cout<<"print guest"<<endl;
		
		guests[i]->print();
	}
}
void Hotel:: printRooms(){
	
	
	roomColl.print();
	
}

