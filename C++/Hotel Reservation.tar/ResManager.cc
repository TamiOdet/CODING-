#include <iostream>
using namespace std;
#include <string>

#include "ResManager.h"
#include "Hotel.h"
void addReservation(string, int, int, int, int, ReqRoomType);

ResManager::ResManager(Hotel* h) : hotel(h)
{
 
 size =0;
 
}

ResManager::~ResManager()
{
	for(int i =0; i<recColl.size(); i++){
		delete recColl[i];
	}

  


}


void ResManager :: setHotel(Hotel* h){
	hotel = h;
}


int ResManager:: getSize(){
	return size;
}


void ResManager :: cpt (Room *room,Guest *guest, int p, int stay){
	room->computePoints(p);
	cout<<"number of points accrued on a daily basis: "<<p<<endl;
	p = stay * p;
	guest->addPts(p);
	cout<<"guest Info:"<<endl;
	guest->print();
	
}

void ResManager :: addRes(Reservation *&r){
	cout<<size<<endl;
	int i;
		
		for(i =0; i< size; i++){
			if(resColl[i]->lessThan(r) == false){
				break;
			}else{
				continue;
			}
		}
		for(int q=size; q>=i; q--){
			
			resColl[q+1] = resColl[q];
		}
			resColl[i] = r;
			size++;	
			


	
	
	
}	
void ResManager :: addReservation(string name, int yr, int mth, int day, int stay, ReqRoomType req){
	
	//Room *room;
	Guest *guest;
	bool t;
	if(stay >= 31 || stay < 1){
		cout<<"Reservation cannot be created because of invalid stay"<<endl;
	}else{
		Date *d = new Date(day, mth, yr);
		Date *d1 = new Date(day, mth, yr);
		for(int i= 0; i< hotel->getRoomColl().getSize(); i++){
			
			if(hotel->getRoomColl().get(i)->getRoomT() == req){
				cout<<"hotel room type "<<hotel->getRoomColl().get(i)->getRoomT()<<" is the same as "<< "reservation room type 					" << req <<endl;
				if(size == 0){
					cout<<"adding first item in res collection"<<endl;
		
					if(hotel->findGuest(name, guest) == false){
						cout<<"Reservation cannot be created because "<<name<<" is not a guest at the hotel"<<endl;
					}else{
						//cout<<"Reservation can be created because "<<name<<" is a guest at the hotel"<<endl;
						Reservation *res = new Reservation (guest, hotel->getRoomColl().get(i), d, stay);
						resColl[size++] = res;
						int pts;
						cpt(hotel->getRoomColl().get(i), guest,  pts, stay);
						notify(res);
						
						break;
					}
				
				}else{
					for(int j =0; j< size; j++){
					
						if(resColl[j]->getR() == hotel->getRoomColl().get(i)){
						cout<<"this room has a reservation in the hotel, but we dont know the date"<<endl;
						
							cout<<"guest"<<guest->getName()<<endl;
							if(resColl[j]->getD()->equals(*d) == false){
								cout<<"The two dates are not equal"<<endl;
								cout<<"arrival date"<<" ";d->print();
								cout<<"Reservation date"<<" "; resColl[j]->getD()->print();
							
						
								for(int x =1; x<= stay; x++){
									//cout<<"old date"<<" "; d->print();
									d1->add(x);
									if(resColl[j]->getD()->equals(*d1) == false){
									
										 t = true;
									}else{
										 t = false;
										 cout<<"reservation cannot be made because the 2 dates are 											equal"<<endl;
										 break;
									}
								}
							}
						}else{
							
							cout<<"room can be reserved as it does not have reservation in hotel"<<endl;
							t = true;

							break;
						}
					}
							
						
							if (t == true){
									
									cout<<"Reservation can be made because the dates dont clash"<<endl;
									
									if(hotel->findGuest(name, guest) == false){
										cout<<"Reservation cannot be created because "<<name<<" is not 											a guest at the hotel"<<endl;
									}else{
										int p;
										cout<<"Date of res"<<endl;
										d->print();
										Reservation *res = new Reservation 
										(guest, hotel->getRoomColl().get(i), d, stay);
										addRes(res);
										cpt(hotel->getRoomColl().get(i), guest,  p, stay);
										notify(res);
										break;
										
									}
								}
							
							}
		
						}
					}
				}

}














void ResManager :: subscribe(Recorder* r){
	recColl.push_back(r);
}

void ResManager :: print(){
	
	for(int i = 0; i<size; i++){
		
		resColl[i]->print();
	}
}

void ResManager ::printRec(){
	for(int i =0; i<recColl.size(); i++){
		
		if(recColl[i]->getName() == "Stay Recorder"){
			cout<<"records for "<<recColl[i]->getName()<<endl;
			recColl[i]->printRecords();
		}else if (recColl[i]->getName() == "Guest Recorder"){
			cout<<"records for "<<recColl[i]->getName()<<endl;
			recColl[i]->printRecords();
		}else if (recColl[i]->getName() == "Upgrade Recorder"){
			cout<<"records for "<<recColl[i]->getName()<<endl;
			recColl[i]->printRecords();
		}	
	}
}

void ResManager :: notify(Reservation* r ){
	for(int i =0; i<recColl.size(); i++){
		recColl[i]->update(r);
	}
}

							
