#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "Date.h"


Date::Date(int d, int m, int y)
{
  //cout<<"in default ctor"<<endl;
  setDate(d, m, y);
}

Date::~Date()
{
  //cout<<"in dtor"<<endl;
}

void Date::setDate(int d,int m,int y)
{
  year  = ( ( y > 0) ? y : 0 );
  month = ( ( m > 0 && m <= 12) ? m : 0 );
  day   = ( ( d > 0 && d <= lastDayInMonth() ) ? d : 0 );
}

void Date::print(){
	cout<<setfill('0')<<setw(4)<<year<<"/"
	 <<setfill('0')<<setw(2)<<month<<"/"
	 <<setfill('0')<<setw(2)<<day<<endl;

}

void Date :: add (int duration){
	cout<<"adding "<<duration<<" days"<<endl;
	if(this->day + duration > 30 && lastDayInMonth() == 30){
		
		this->month = this->month + 1;
		this->day = (this->day + duration) - 30;
		this->setDate(day, month, year);
	}else if(this->day + duration > 31 && lastDayInMonth() == 31){
		if(this->month == 12){
			this->year = year + 1;
			this->month = 1;
			this->day = (this->day + duration) - 31;
			this->setDate(day, month, year);
		}else{
			
			this->month = this->month + 1;
			this->day = (this->day + duration) - 31;
			this->setDate(day, month, year);
		}
	}else if (this->day + duration> 28 && lastDayInMonth() == 28) {
		
		this->month = this->month + 1;
		this->day = (this->day + duration) - 28;
		this->setDate(day, month, year);
	}else if(this->day + duration> 29 && lastDayInMonth() == 29){
			
			this->month = this->month + 1;
			this->day = (this->day + duration) - 29;
			this->setDate(day, month, year);
	
	}else{
		this->day = this->day + duration;
		this->setDate(day, month, year);
	}
	
	cout<<"new date"<<endl; this->print();
	 
}

int Date::lastDayInMonth()
{
  switch(month)
  {
    case 2:
      if (leapYear())
        return 29;
      else
        return 28;
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
      return 31;
    default:
      return 30;
      
  }
}

bool Date::lessThan (Date &d){
	
	bool t = false;
	
	if(this->year < d.year){
		
		t=true;
		//this->print();
		//cout<<"is less than"<<endl;
		//d.print();
	}else if(this->year == d.year){
		if(this->month < d.month){
			
			t=true;
			//this->print();
			//cout<<"is less than"<<endl;
			//d.print();
		}else if(this->month == d.month){
			
			if(this->day < d.day){
				
				t=true;
				//this->print();
				//cout<<"is less than"<<endl;
				//d.print();
	
			}
		}
	}

	
	return t;		
}


bool Date :: equals (Date& d){
	if (this->year == d.year){
		if(this->month == d.month){
			if(this->day == d.day){
				//cout<<"these two dates are equal"<<endl;
				return true;
				
			}
		}
	}
	//cout<<"these two dates are not equal"<<endl;
	return false;
}

bool Date::leapYear()
{
  if ( year%400 == 0 ||
       (year%4 == 0 && year%100 != 0) )
    return true;
  else
    return false;
}

string Date::getMonthStr() const
{
  string monthStrings[] = { 
    "January", "Februrary", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December" };

  if ( month >= 1 && month <= 12 )
    return monthStrings[month-1];
  else
    return "Unknown";
}

