#include <iostream>
#include <sstream>
using namespace std;
#include <string>
#include <vector>

#include "StayRecorder.h"


StayRecorder::StayRecorder(string n) : Recorder(n)
{
	
}



void StayRecorder :: update (Reservation* r){

		string gue = r->getG()->getName();
		int st = r->getStay();
		if(st > 3){
			recColl.push_back("Stay Recorder:  Guest    " + gue + "    length of stay:    " + to_string(st) + "  nights");
			
		}
	
}
