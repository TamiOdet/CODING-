#include <iostream>
#include <string>
using namespace std;
#include "Room.h"

int getRoomN();
float getPrice();
ReqRoomType getRoomT();
void print();
void computePoints(int&);

Room::Room (ReqRoomType r, int n, float p) : roomT(r), roomN(n), price(p)
{
 
}

int Room::getRoomN() { return roomN; }
float Room::getPrice() { return price; }
ReqRoomType Room::getRoomT() { return roomT; }


string Room:: inString(){
	string s;
	if(roomT == C_REG){
		s = "Regular";
	}else if (roomT ==  C_PREM){
		s = "Premium";
	}else if (roomT == C_SUITE){
		s = "Suite";
	}
	return s;
}
void Room::computePoints(int& pts){
	if(roomT == C_SUITE){
		pts = (int)price * .20;
	}else if(roomT == C_PREM){
		pts = (int) price * .15;
	}else if(roomT == C_REG){
		pts = (int) price * .10;
	}
	
}


void Room::print()
{ 
	cout<<"RoomType: "<< inString()<<endl;
	cout<<"Room Number:  "<<roomN<<endl;
	cout<<"Room price:  $"<<price<<endl;
}

