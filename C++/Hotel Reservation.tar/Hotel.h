#ifndef HOTEL_H
#define HOTEL_H
#include "Room.h"
#include "Guest.h"
#include "RoomArray.h"
#include "ResManager.h"
//Class: Hotel
//Purpose: Contains the various types of rooms as well as keeps track of the multiple guests that stay at the hotel


class Hotel
{
  public:
    Hotel(string, ResManager*);
    ~Hotel();
    
    RoomArray getRoomColl();
    void addGuest(Guest*);
    void addRoom(Room*);
    void  printGuests();
    void printRooms();
    bool findGuest(string, Guest*&);

  private:

   string hotel;
   Guest* guests[MAX_ARR];
   int   size;
   RoomArray roomColl;
   ResManager* man;
   
    
};

#endif
