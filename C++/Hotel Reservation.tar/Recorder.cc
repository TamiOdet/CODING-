#include <iostream>
using namespace std;
#include <string>
#include <vector>

#include "Recorder.h"


Recorder::Recorder(string r) : record(r)
{

}

Recorder::~Recorder(){}


string Recorder :: getName(){
	return record;
}
void Recorder :: printRecords(){
	//cout<<record<<endl;
	
	for(int i = 0; i< recColl.size(); i++){
		cout<<recColl[i] <<endl;
	}
}


