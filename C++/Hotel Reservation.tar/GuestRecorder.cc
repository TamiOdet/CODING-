#include <iostream>
#include <sstream>
using namespace std;
#include <string>
#include <vector>

#include "GuestRecorder.h"


GuestRecorder::GuestRecorder(string n) : Recorder(n)
{
	
}



void GuestRecorder :: update (Reservation* r){
	
	string gue = r->getG()->getName();
	if( r->getG()->getIsPrem() == false){
		if(r->getR()->getRoomT() == C_SUITE || r->getR()->getRoomT() == C_PREM) {
			recColl.push_back("Guest Recorder: " + gue);
		}
	}
		
			
			
		
	
}
