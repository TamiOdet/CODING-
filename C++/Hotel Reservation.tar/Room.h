#ifndef ROOM_H
#define ROOM_H

#include "defs.h"
//Class: Room
//Purpose: Responsible for the creation of a room, taking in a specific room type, number, and price of the room
class Room
{
  public:
    Room(ReqRoomType, int, float);
    int   getRoomN();
    float   getPrice();
    ReqRoomType   getRoomT();
    void  print();
    void computePoints(int&);
    string inString();

  private:
    
    float price;
    
    int   roomN;
    
    ReqRoomType roomT;
};

#endif

