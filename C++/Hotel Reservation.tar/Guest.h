#ifndef GUEST_H
#define GUEST_H

#include "defs.h"
//Class: Guest
//Purpose: contains the info for each guest in the hotel including: whether they are premium, lyalty points#, and guest name


class Guest
{
  public:
    Guest(string, bool = false);
    string getName();
    bool getIsPrem();
    void  print();
    void addPts(int);

  private:

    int loyalP;
    string guest;
    bool isPrem;
    
};

#endif
