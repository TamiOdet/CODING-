#ifndef DEFS_H
#define DEFS_H

#define MAX_ARR  256

typedef enum {C_REG, C_PREM, C_SUITE}
ReqRoomType;

#endif

