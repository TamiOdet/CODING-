#ifndef RECORDER_H
#define RECORDER_H
#include "Reservation.h"
#include <vector>
//Class: Recorder
//Purpose: base class responsible for the recorders name and looping over the recorders collection and printing it out


class Recorder
{
  public:
    virtual void update (Reservation*) = 0;
    Recorder(string);
    string getName();
    ~Recorder();
    void printRecords();
    
  protected:
  
  string record;
  vector<string> recColl;
 };
 
 #endif
 
 
   
    
