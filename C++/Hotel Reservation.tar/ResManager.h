#ifndef RESMANAGER_H
#define RESMANAGER_H
class Hotel;
#include "Reservation.h"
#include "Recorder.h"
#include "defs.h"
#include <vector>

//class: Res Manager
//Purpose: responsible for checking which room of the requested type is available for the duration of the guests stay
class ResManager
{
  public:
    ResManager(Hotel* = NULL);
    ~ResManager();
    void setHotel(Hotel*);
    void addReservation(string, int, int, int, int, ReqRoomType);
   void subscribe(Recorder*);
   void printRec();
   void cpt (Room*, Guest*, int, int);
   void addRes(Reservation*&);
   int getSize();
   void print();

  private:
   Hotel *hotel;
   Reservation * resColl[MAX_ARR];
   int size;
   vector<Recorder*> recColl;
   void notify(Reservation*);
   
   
    
};

#endif
