#ifndef UPGRADE_RECORDER_H
#define UPGRADE_RECORDER_H
#include "Reservation.h"
#include "Recorder.h"
//Class: Upgrade Recorder
//Purpose: responsible for callling the upate function that checks if the reservation is for a regular guest willing to spend more than 1500, with the reservation and if so, adds them to its collection 

class UpgradeRecorder : public Recorder
 {
 public:
	UpgradeRecorder(string);
	virtual void update (Reservation*);
};
#endif
