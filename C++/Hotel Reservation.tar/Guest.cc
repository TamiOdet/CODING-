#include <iostream>
using namespace std;
#include <string>
#include "Guest.h"
string getName();
bool getPrem();
void  print();

Guest::Guest(string g, bool p) : guest(g), isPrem(p)
{

 loyalP = 0;
}



string Guest :: getName(){
	//cout<<"the pointer points to the variable"<< guest<<endl;
	return guest;
	
}

bool Guest :: getIsPrem(){
	return isPrem;
}

void Guest :: addPts(int p){
	loyalP = loyalP + p;
}


void Guest:: print(){
	cout<<"Guest name: "<< guest<<endl;
	cout<<"Premium member:"<<endl;
	if (isPrem == 1){
	cout<<"yes"<<endl;
	}else{
	cout<<"no"<<endl;
	}
	cout<<"Guest LoyalPoints Amount:"<<loyalP<<endl;
}

