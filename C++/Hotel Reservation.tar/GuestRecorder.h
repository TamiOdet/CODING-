#ifndef GUEST_RECORDER_H
#define GUEST_RECORDER_H
#include "Reservation.h"
#include "Recorder.h"

//Class: GuestRecorder
//Purpose: is derived from the recorder class and contains and update function that adds guest to the collection if they are a regular guest staying in a premuim or suite room
class GuestRecorder : public Recorder
 {
 public:
	GuestRecorder(string);
	virtual void update (Reservation*);
};
#endif
	

