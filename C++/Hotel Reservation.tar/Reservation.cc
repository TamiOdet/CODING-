#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
using namespace std;
#include "Reservation.h"


Reservation::Reservation(Guest *g, Room* r, Date* d, int s) : guest(g), resRoom(r), resDate(d), stay(s)
{
	
	resCost = resRoom->getPrice() * stay;
}

Reservation::~Reservation()
{

	//delete resDate;
	//delete resRoom;
	delete guest;
}


float Reservation :: getResCost(){
	//cout<<"cost: "<< resCost<<endl;
	return resCost;
}
int Reservation :: getStay(){
	//cout<<"length of stay: "<< stay<<endl;
	return stay;
}
Guest* Reservation :: getG(){
	//cout<<"Reservation Guest: "<< guest<<endl;
	return guest;
}
Date* Reservation :: getD(){
	//cout<<"Reservation Date: "<< resDate<<endl;
	return resDate;
}
Room* Reservation :: getR(){
	//cout<<"Room reserved"<<endl;
	return resRoom;
}


bool Reservation::lessThan(Reservation* r){
	Date t = *r->resDate;
	if(this->resDate->lessThan(t)){
		
		return true;
	}
	
	return false;
}


void Reservation::print(){
	//removed guest getter
	//..recColl.push_back("Stay Recorder:  Guest    " + gue + "   " + " length of stay: " + to_string(st) + "  nights");
	cout<<"Guest name: "<<guest->getName()<<" ";
	cout <<"Room:  "<<resRoom->getRoomN()<< " ";
	cout <<"Arrival Date:  "; resDate->print();
	cout<<"Total:  "<< resCost<<" ";
	
	cout<<""<<endl;
}
