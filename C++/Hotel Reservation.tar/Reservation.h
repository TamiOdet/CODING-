#ifndef RESERVATION_H
#define RESERVATION_H
#include "Room.h"
#include "Guest.h"
#include "RoomArray.h"
#include "Date.h"
//Class: Reservation
//Purpose: contains information for making a reservation including the guest, date, room, and length of stay

class Reservation
{
  public:
    Reservation(Guest*,Room*, Date*, int);
    ~Reservation();
    float getResCost();
    int getStay();
    Guest* getG();
    Date* getD();
    Room* getR();
  
    bool lessThan(Reservation*);
    void print();
    

  private:

   Guest* guest;
   Date* resDate;
   int   stay;
   Room* resRoom;
   float resCost;
   
    
};

#endif
