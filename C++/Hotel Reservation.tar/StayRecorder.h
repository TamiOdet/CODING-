#ifndef STAY_RECORDER_H
#define STAY_RECORDER_H
#include "Reservation.h"
#include "Recorder.h"
//Class: StayRecorder
//Purpose: Responsible for checking if the duratiion of the stay is longer than 3 days and if it is, format the guests string and add it to the collection

class StayRecorder : public Recorder
 {
 public:
	StayRecorder(string);
	virtual void update (Reservation*);
};
#endif
	

   
