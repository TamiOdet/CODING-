#include <iostream>
#include <sstream>
using namespace std;
#include <string>
#include <vector>

#include "UpgradeRecorder.h"


UpgradeRecorder::UpgradeRecorder(string n) : Recorder(n)
{
	
}


void UpgradeRecorder :: update (Reservation* r){
	
	//string stream (form it)
	//add string representation
	string gue = r->getG()->getName();
	int c = r->getResCost();
	if( r->getG()->getIsPrem() == false){
		if(r->getResCost() > 1500) {
			recColl.push_back("Upgrade Recorder: " + gue + "   " +  "Total charge: " + "$"+to_string(c));
		}
	}
		
			
			
		
	
}
