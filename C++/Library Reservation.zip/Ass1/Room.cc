
#include "Room.h"

	

Room::Room(string n, int ca, int co, bool w){
	name = n;
	cap = ca;
	comp = co;
	whiteb = w;
}

Room::Room(const Room& r){
	name = r.name;
	cap = r.cap;
	comp = r.comp;
	whiteb = r.whiteb;
	
}
//setters
void Room::setName(string n){
	name = n;
}

void Room::setCap(int ca){
	cap = ca;
}

void Room::setComp(int co){
	comp = co;
}

void Room::setWhiteboard(bool w){
	whiteb = w;
}


//getters
string Room::getName(){ return name; }
int Room::getCap(){ return cap; }
int Room::getComp(){ return comp; }
bool Room::hasWhiteboard(){return whiteb; }


//other


bool Room::meetsCriteria(int capacity, int computers, bool whiteboard){
	if((cap >= capacity) && (computers == 0) && (whiteboard == NULL)){
		return true;
		}
	else if(cap >= capacity){
		if(comp >= computers){
			if (whiteb == whiteboard){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}		
	}else{
		return false;
	}
	return false;
}

void Room::print(){
	cout << "Room name:  "<<getName()<<" "<<"Capacity:  "<<getCap()<<", "<<"Number of computers:  "<<getComp()<<", "<<"does it have whiteboard?  "<<hasWhiteboard()<< " " <<endl;
}

bool Room::lessThan(Room& r){
	if(name > r.name){
		printf("true");
		return true;
	}else{
		printf("false");
		return false;
	}
}


