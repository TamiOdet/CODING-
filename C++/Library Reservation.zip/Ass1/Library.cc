
#include "Library.h"

Library::Library(){
	stuS = 0;
	roomS = 0;
	resS = 0;
	
	stuArray = new Student*[MAX_ARR];
	resArray = new Reservation*[MAX_ARR];
}

Library::~Library(){
	for (int i = 0; i< stuS; ++i){	
		delete stuArray[i];
	}
	delete [] stuArray;
	
	for(int i =0; i< roomS; ++i){
		delete roomArr[i];
	}
	for(int i =0; i< resS; ++i){
		delete resArray[i];
	}
	delete [] resArray;
	
	
}

bool Library::addStudent(const string& name, const string& number){
	if(stuS >= MAX_ARR){
		cout<<"there is no space left in the student array"<<endl;
		return false;
	}else{
		Student *newStu = new Student(name,number);
		stuArray[stuS++] = newStu;
		return true;
	}
	
	
}





bool Library:: addRoom(string n, int ca, int co, bool w){
	if(roomS >= MAX_ARR){
		cout<<"there is no space left in the room array"<<endl;
		return false;
	}else{
		Room *newRoom = new Room(n,ca,co,w);
		roomArr[roomS++] = newRoom;
		return true;
	}
}

void Library:: studentPrint(){
	for(int i =0; i< stuS; ++i){
			cout<<"did it com here"<<endl;
			stuArray[i]->print();
			}
}

//confused about what i should be getting
bool Library::getStudent(const string& name, Student** student){
	bool x=true;
	for (int i =0; i< stuS; ++i){
		if(stuArray[i]-> getName() == name){
			*student = stuArray[i]; 
			return true;
		}
	}
		
}

bool Library::getRoom(const string& roomName, Room** room){
	bool x=true;
	for (int i =0; i< roomS; ++i){
		if(roomArr[i]-> getName() == roomName){
			*room = roomArr[i]; 
			return true;
		}
	}
}
bool Library::isFree(const string& room, Date& d){
	if(resS == 0){
	
		return true;
	}
	int x = false;
	for (int i =0; i< roomS; ++i){
		
		if(roomArr[i]-> getName() == room){ 
			
			x = true;
		}
	} 
	if(x == true){

	int y = true;
		for (int i = 0; i< resS; i++){
			
			if((resArray[i]->overlaps(room,d)) == true){
			
				y = false;
			}else{
			
				y = true;
			}
		}
	return y;
	}
	
	return x;
}

bool Library::makeReservation(const string& student, const string& room, Date& d){

	Student *stu = NULL;
	Room *roo = NULL;
	if (resS >= MAX_ARR){
		return false;
	}		
	if((getStudent(student, &stu) == false) ||(getRoom(room, &roo)) == false){
		
		return false;
	}else{
		
		if(isFree(room, d) == true){
			
			Reservation *newRes = new Reservation(stu,roo,d);
			resArray[resS] = newRes;
			resS++;
			
			return true;
		}else{
			
			return false;
		}
	}
}

	


void Library::printReservations(){
	for(int i =0; i<resS; ++i){
		resArray[i]->print();
	}
}


