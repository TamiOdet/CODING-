#ifndef LIBRARY_H
#define LIBRARY_H
#define MAX_ARR 100
#include "Room.h"
#include "Student.h"
#include "Date.h"
#include "Reservation.h"
//Class: Reservation
//Purpose: contains information for making a reservation including the guest, date, room, and length of stay

class Library
{
  public:
    Library();
    ~Library();
    
    bool addStudent(const string&, const string&);
    bool addRoom(string, int = 1, int = 0, bool = NULL);
    bool getStudent(const string& name, Student** student);
    bool getRoom(const string& roomName, Room** room);
    bool isFree(const string& room, Date&);
    bool makeReservation(const string& student, const string& room, Date& d);
    bool overlaps(const string&, Date&);
    void printReservations();
    void studentPrint();
    
    

  private:
	
   Student** stuArray;
   Room* roomArr[MAX_ARR];
   Reservation** resArray;
   int stuS;
   int roomS;
   int resS;
    
};

#endif

