#ifndef ROOM_H
#define ROOM_H
#include <iostream>
#include <string>

using namespace std;

class Room {
		
	public:
		//constructor
		
		Room(string, int = 1, int = 0, bool = true);
		
		//copy constructor
		Room(const Room&); 
		
				
		//setters
		void setName(string);
		void setCap(int);
		void setComp(int);
		void setWhiteboard(bool);
		
		
		//getters
		string getName();
		int getCap();
		bool hasWhiteboard();
		int getComp();
		
		
		
		//other
		bool meetsCriteria(int = 1, int = 0, bool = NULL);
		bool lessThan(Room&);
		void print();
	
	private:
		
		//variables
		string name;
		int cap;
		int comp;
		bool whiteb;
		
		
		
		
};
#endif
