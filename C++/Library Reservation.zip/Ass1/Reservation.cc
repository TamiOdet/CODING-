#include <string>
#include "Reservation.h"
using namespace std;



Reservation::Reservation(Student *s, Room* r, Date& d)
{
	stu = s;
	room = r;
	date.setDate(d);
}

Reservation::~Reservation()
{

}




Student Reservation::getStu(){
	cout<<"Reservation Student: "<<endl;
	return *stu;
}

Date Reservation::getD(){
	cout<<"Reservation Date: "<<endl;
	return date;
}
Room Reservation::getR(){
	cout<<"Room reserved"<<endl;
	return *room;
}


bool Reservation::lessThan(Reservation* res){

	if(this->date.lessThan(res->date)){
		return true;
	}
	
	return false;
}


bool Reservation::overlaps(const string& r, Date& d){
	if(r == room->getName()){
		if(this->date.overlaps(d)){
		
			return true;
		}else{
			return false;
		}
		
	}
	return false;
}


void Reservation::print(){
	
	cout<<"Student Reservation info:"<<endl;
	stu->print();
	room->print();
	date.print();
	
	
	cout<<""<<endl;
}

