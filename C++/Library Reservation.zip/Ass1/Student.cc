
#include "Student.h"

Student::Student(){
	name = "";
	number = "Invalid";
}

Student::Student(string nam, string num){
	name = nam;
	number = num;
}

Student::Student(const Student& s){
	name = s.name;
	number = s.number;
}


void Student::setName(string na){
	name = na;
}

void Student::setNumber(string nu){
	number = nu;
}


//getters
string Student::getName(){ return name; }
string Student::getNumber(){ return number; }


//other

bool Student::lessThan(Student& s){
	if (this->number < s.number ){
		return true;
	}else{
		return false;
		
	}
}
//All Classes must have print function
void Student::print(){
	cout << "Student name: "<< getName()<<" Student num: "<<getNumber()<<endl;
}

