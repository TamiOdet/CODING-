#include <iostream>
using namespace std;
#include <string>


#include "Student.h"
#include "Room.h"
#include "Date.h"
#include "Reservation.h"
#include "a1-global.cc"




int main()
{ 
  
Date d1(2020,1,24,11,3);
Date d2(2020,1,23,11,3);
testDate(d1,d2,false);

Date d3(2020,1,24,7,3);
Date d4(2020,1,24,10,3);
//d3.overlaps(d4);
testDate(d3,d4,false);

Date d5(2020,1,24,7,1);
Date d6(2020,1,24,8,3);
testDate(d5,d6,false);

Date d7(2020,1,24,7,3);
Date d8(2020,1,24,9,1);
testDate(d7,d8,true);

Date d9(2020,1,24,7,3);
Date d10(2020,1,24,7,1);
testDate(d9,d10,true);

Library *lib = new Library();
populate(*lib);
testReservations(*lib);


delete lib;
}


  
 
 
