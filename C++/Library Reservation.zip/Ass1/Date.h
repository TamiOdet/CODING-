
#ifndef DATE_H
#define DATE_H
#define MAX_DUR 3
#include <iostream>
#include <string>

using namespace std;

class Date {
		
	public:
		//constructor
		Date();
		Date(int year, int month, int day, int hour, int dur);

		
		//setters
		void setDay( int);
		void setMonth(int);
		void setYear(int);
		void setDate(int, int, int, int, int);
		void setDate(Date&);
		void setHour(int);
		void setDur(int);
		
		//getters
		int getDay();
		int getMonth();
		int getYear();
		string getMonthName();
		int getHour();
		int getDur();
		
		//other
		bool lessThan(Date& d);
		bool overlaps(Date& d);
		void print();
	
	private:
		//functions
		int getMaxDay();	
	
		//variables
		int day;
		int month;
		int year;
		int hour;
		int dur;

};
#endif
