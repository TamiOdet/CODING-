#ifndef RESERVATION_H
#define RESERVATION_H
#include "Room.h"
#include "Student.h"
#include "Date.h"
//Class: Reservation
//Purpose: contains information for making a reservation including the guest, date, room, and length of stay

class Reservation
{
  public:
    Reservation(Student*,Room*, Date&);
    ~Reservation();
    Student getStu();
    Date getD();
    Room getR();
  
    bool lessThan(Reservation*);
    bool overlaps(const string&, Date&);
    void print();
    

  private:
	
   Student* stu;
   Room* room;
   Date date;
   
   
    
};

#endif

